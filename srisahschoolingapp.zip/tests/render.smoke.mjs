/**
 * Browser-render smoke test.
 *
 * Compiles the real React portal into a classic (IIFE) bundle, loads it in jsdom with a
 * stubbed API and asserts that the sign-in screen renders without errors. This catches
 * broken imports, JSX mistakes and render-time crashes that unit tests cannot see.
 *
 * Run with:  npm run test:render
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { build } from 'vite';
import react from '@vitejs/plugin-react';
import { JSDOM, VirtualConsole } from 'jsdom';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

test('the compiled portal renders the sign-in screen', { timeout: 240_000 }, async () => {
  const outDir = fs.mkdtempSync(path.join(os.tmpdir(), 'srisah-render-'));
  await build({
    root: path.join(root, 'web'),
    plugins: [react()],
    logLevel: 'error',
    build: {
      outDir,
      emptyOutDir: true,
      copyPublicDir: false,
      lib: { entry: path.join(root, 'web', 'src', 'main.jsx'), name: 'SriSahPortal', formats: ['iife'], fileName: () => 'portal.iife.js' },
      cssCodeSplit: false,
    },
    define: { 'process.env.NODE_ENV': '"production"' },
  });

  /** Library builds land flat in outDir; application builds nest under assets/. */
  function collectFiles(dir) {
    return fs.readdirSync(dir, { withFileTypes: true }).flatMap((entry) => {
      const full = path.join(dir, entry.name);
      return entry.isDirectory() ? collectFiles(full) : [full];
    });
  }
  const files = collectFiles(outDir).map((file) => path.relative(outDir, file));
  const bundle = files.find((name) => name.endsWith('.js'));
  assert.ok(bundle, `a JavaScript bundle was produced (saw: ${files.join(', ')})`);
  const code = fs.readFileSync(path.join(outDir, bundle), 'utf8');

  const errors = [];
  const virtualConsole = new VirtualConsole();
  virtualConsole.on('jsdomError', (error) => errors.push(error.message));
  virtualConsole.on('error', (message) => errors.push(String(message)));

  const dom = new JSDOM('<!doctype html><html><body><div id="root"></div></body></html>', {
    runScripts: 'outside-only',
    pretendToBeVisual: true,
    url: 'https://portal.example.test/',
    virtualConsole,
  });
  const { window } = dom;

  // Minimal API stub: no session, so the portal must fall back to the sign-in screen.
  window.fetch = async (url) => {
    const target = String(url);
    const payload = target.includes('/api/auth/me') ? { user: null } : { message: 'stubbed' };
    return {
      ok: true,
      status: 200,
      headers: { getSetCookie: () => [] },
      json: async () => payload,
      text: async () => JSON.stringify(payload),
    };
  };
  window.matchMedia = window.matchMedia || (() => ({ matches: false, addEventListener() {}, removeEventListener() {} }));

  window.eval(code);
  await new Promise((resolve) => setTimeout(resolve, 1200));

  const rootElement = window.document.getElementById('root');
  const text = rootElement.textContent || '';
  assert.ok(rootElement.children.length > 0, 'React mounted into #root');
  assert.match(text, /Welcome back/, 'the sign-in screen rendered');
  assert.match(text, /SriSah Schooling/, 'the brand is present');
  assert.equal(errors.length, 0, `no runtime errors: ${errors.join(' | ')}`);

  // The violet rebrand must be present in the compiled stylesheet.
  const css = files.find((name) => name.endsWith('.css'));
  assert.ok(css, 'a stylesheet was produced');
  const styles = fs.readFileSync(path.join(outDir, css), 'utf8');
  assert.match(styles, /#6d3fd1/i, 'violet accent colour is compiled into the stylesheet');
  assert.ok(!/#173d32/i.test(styles), 'the legacy forest-green brand colour is gone');

  fs.rmSync(outDir, { recursive: true, force: true });
});
