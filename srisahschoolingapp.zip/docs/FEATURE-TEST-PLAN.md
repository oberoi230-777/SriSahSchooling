# Feature test plan

Run this plan against a disposable PostgreSQL database and a non-production deployment with email delivery configured. Do not mark a case complete until it has been executed and recorded by the school operator.

## Automated checks

Run `npm run verify` for the database-free gate, or `npm test` plus `npm run test:render`
against a disposable database for the full run. Status below was recorded on the release
build in this repository.

- [x] Unit tests in `tests/security.test.js`: email normalization, opaque-token shape/hash, password policy, scrypt verification.
- [x] End-to-end role journey in `tests/api.e2e.test.js` (`npm run test:e2e`): 16 scenarios over real HTTP covering registration, verification, invitations, CSRF, origin rejection, all four roles, the full teaching cycle, review and resubmission, invoices, enquiries, password reset and logout.
- [x] PostgreSQL integration test in `tests/postgres.integration.test.js` (`npm run test:integration`): parent, student and teacher row isolation, parent invoice/homework isolation, student submission visibility and denied cross-student teacher writes. Requires separate migration and restricted app URLs.
- [x] Browser render smoke test in `tests/render.smoke.mjs` (`npm run test:render`): the compiled portal mounts, renders the sign-in screen with zero runtime errors, and carries the violet theme.
- [x] Production build with `npm run build`.
- [x] Android web bundle and Capacitor sync with `npm run android:sync` (splash-screen and status-bar plugins registered).
- [x] Package/dependency check with `npm audit` (no reported vulnerabilities).

> Row-level-security assertions only run when `DATABASE_URL` uses a non-owner,
> non-superuser, `NOBYPASSRLS` role. The suites report a diagnostic instead of a false pass
> when the connection can bypass RLS.

## Account lifecycle

- [ ] Register a parent with the correct organization slug/family code; confirm a `pending` account is not accepted at login before email verification.
- [ ] Verify the one-time email link; confirm a session starts and the parent can create a student profile.
- [ ] Attempt registration with a wrong enrollment code and an already-used email; confirm no account or data is exposed.
- [ ] Invite a student from a linked profile; accept the one-time link, set a password, sign in and confirm only the linked student is returned by `/api/students`.
- [ ] Invite a teacher as admin; confirm the teacher is pending until activation, can be assigned before activation, and can sign in only after activation.
- [ ] Resend a pending teacher invitation and a still-pending student invitation; confirm a fresh token invalidates the old one.
- [ ] Request password reset for an existing and non-existing email; confirm the response is generic. Reset with a valid one-time link and confirm old sessions are revoked.
- [ ] Try invalid, expired and reused verification/reset/invitation links; confirm they cannot activate accounts, set passwords or create sessions.
- [ ] Sign out; confirm the session cookie is revoked and subsequent protected API requests return `401`.

## Student records and role access

- [ ] Parent A creates two students; confirm both appear in that parent's picker and profile area.
- [ ] Parent B creates or is linked to a different student; use Parent B's session to request Parent A's student UUID from profile, dashboard, classes, homework, attendance, tests, updates, reports, improvement, messages and invoices. Confirm `404`, empty result or denied access—never record data.
- [ ] Student A signs in; request Student B's UUID from each student-scoped read endpoint. Confirm no cross-student result.
- [ ] Teacher A is assigned to Student A; confirm only assigned learners appear in the roster, picker and dashboard.
- [ ] Teacher A tries to create homework, a test, attendance, learning update, improvement action or class enrollment for unassigned Student B. Confirm denial and no persisted record.
- [ ] Remove Teacher A's assignment; confirm subsequent reads/writes to that student's records are denied.
- [ ] Link a second verified parent account to a student as admin; confirm both linked parents can read that student's information, and neither can read unlinked students.
- [ ] Delete a student as admin after confirming retention rules; confirm linked student sessions are revoked and dependent records are removed. Confirm the audit event remains.

## Learning workflows

- [ ] Admin/teacher schedules a future class for one or more accessible students; confirm it appears in the correct parent/student schedule and does not appear in unrelated accounts.
- [ ] Teacher assigns homework; confirm only the selected learner/family and assigned teacher can read it.
- [ ] Student submits text work; confirm it appears to the student, linked parent and assigned teacher. Submit an update and confirm it replaces the current submission without creating a second row.
- [ ] Teacher reviews work, saves optional score/feedback and marks `Needs revision`; confirm the student can update and resubmit. Mark reviewed; confirm the student's edit action is hidden.
- [ ] Teacher records a test with valid score/max score; reject negative scores and scores above max. Confirm reports/dashboard recalculate from saved data.
- [ ] Mark attendance for an enrolled student/class; confirm it appears only to accessible roles and affects report percentages.
- [ ] Share a learning update and improvement action; confirm data appears for the correct learner and a student/parent can mark an action complete.
- [ ] Send a message as parent, student and assigned teacher; confirm only linked/assigned roles can read it, current-user styling uses sender ID, and unassigned teacher access is denied.
- [ ] Add an HTTPS learning material; confirm organization users can view it. Reject non-HTTPS resource URLs.
- [ ] Create and read an invoice ledger record; confirm only the linked parent/admin can see it. Confirm no payment is attempted or represented as collected.
- [ ] Submit an enquiry and process its status as admin; confirm teacher, parent and student accounts cannot read the organization enquiry inbox.

## Android / PWA and release

- [ ] Complete the role privacy checks in `docs/ANDROID-TESTING.md` on a physical Android device over HTTPS.
- [ ] Install from Chrome; confirm standalone launch, sign-in, keyboard usability, portrait/landscape layout and safe-area spacing.
- [ ] Offline, confirm only the application shell/static assets load; no student/API records are served from cache and no write is queued.
- [ ] Check database backup and restore in a disposable environment, health endpoint, email delivery, logs and rollback plan before real-school use.

## Authoring-environment result

Unit tests and the production Vite build were executed successfully. The PostgreSQL RLS integration case was present but skipped because this environment had no PostgreSQL client or Docker runtime; no actual database migration/RLS result is claimed. No physical Android device was available, so the Android checklist remains unexecuted.
