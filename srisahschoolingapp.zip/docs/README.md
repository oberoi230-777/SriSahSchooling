# SriSah Schooling — documentation index

Everything you need to run, brand, test, ship and operate SriSah Schooling. Start with the
guide that matches what you are trying to do right now.

| # | Guide | Read it when you want to… |
|---|-------|---------------------------|
| 0 | [Complete guide](COMPLETE-GUIDE.md) | end-to-end setup, role logins, daily workflow, testing and production checklist |
| 1 | [Getting started](GETTING-STARTED.md) | install the project on your own computer and sign in for the first time |
| 2 | [App guide](APP-GUIDE.md) | learn what every screen does, role by role (admin, parent, student, teacher) |
| 3 | [Theme guide](THEME-GUIDE.md) | change the violet/purple brand, colours, logo and app icons |
| 4 | [Build & test guide](BUILD-AND-TEST.md) | build, package, test and verify the web app and the Android app |
| 5 | [Web deployment](WEB-DEPLOYMENT.md) | put the portal online with HTTPS, a real database and backups |
| 6 | [Play Store deployment](PLAY-STORE-DEPLOYMENT.md) | publish the Android app to Google Play, step by step |
| 7 | [Android testing](ANDROID-TESTING.md) | device test the installed app and the progressive web app |
| 8 | [Operations](OPERATIONS.md) | run the school day to day: onboarding, access reviews, backups, upgrades |
| 9 | [API reference](API.md) | call or extend the HTTP API |
| 10 | [Feature test plan](FEATURE-TEST-PLAN.md) | sign off the release with a role-by-role acceptance checklist |
| 11 | [Troubleshooting](TROUBLESHOOTING.md) | fix an error message you just saw |

## The one-page mental model

```
                        ┌──────────────────────────────┐
   Browser  ─────────►  │  Node + Express API          │
   Android app ───────► │  server/  (port 3001)        │  ─────►  PostgreSQL 16+
   (Capacitor WebView)  │  + serves the built React UI │          db/, row-level security
                        └──────────────────────────────┘
                                     ▲
                        built from   │  npm run build   →  web/dist
                        React source │  npm run android:sync → android/ app bundle
                                     │
                              web/src/  (React + violet theme)
```

* **One codebase, three surfaces.** The same React portal is served by the Node server for
  the browser, installed as a PWA on Android/iOS, and packaged as a native Android app in
  `android/`.
* **One database, strict isolation.** Every read and write runs inside a transaction that
  sets the caller's role and identity; PostgreSQL row-level security enforces who may see
  which learner.
* **No demo student data.** The database starts empty on purpose. An administrator creates
  real profiles after deployment.

## Quick command reference

```sh
npm ci                  # install dependencies
npm run migrate         # create/upgrade the database schema
npm run bootstrap       # create the first organization + administrator (once)
npm run dev             # API on :3001 and the portal on http://localhost:5173
npm test                # unit + end-to-end tests (database tests skip if no DATABASE_URL)
npm run test:render     # compile and render the real UI in jsdom
npm run build           # production web assets in web/dist
npm run android:sync    # build + copy web assets into the Android project
npm run android:release # signed Android App Bundle for Google Play
```

Full detail for every script: [Build & test guide](BUILD-AND-TEST.md).
